# Executive Summary

A pre-order bakery with subscription boxes, batching, and controlled delivery zones.

## Recommendation

Run a narrow paid pilot before committing to permanent premises, custom technology, or a large team. Continue only when customers pay the proposed price, the workflow is reliable, and repeat demand supports the fixed-cost base.

## Decision gates

- At least 30 target-customer interviews and 10 paid pilot users.
- Two supplier or fulfilment quotations with clear service levels.
- Written activity-specific licensing guidance.
- A downside cash-flow case with at least three months of runway.
