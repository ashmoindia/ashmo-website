# Launch Readiness Checklist

## Demand

- [ ] Interview 30 to 50 target customers.
- [ ] Secure at least 10 paid pilot users.
- [ ] Validate willingness to repeat at the proposed price.

## Operations

- [ ] Document the service workflow and quality checks.
- [ ] Compare at least two supplier or fulfilment options.
- [ ] Define refund, complaint, and escalation procedures.

## Compliance

- [ ] Confirm every licensed activity in writing.
- [ ] Confirm premises, staffing, insurance, and activity-specific approvals.
- [ ] Review VAT, corporate tax, employment, and record-keeping obligations.

## Finance

- [ ] Replace every estimate with current quotations.
- [ ] Complete downside, base, and upside cash-flow cases.
- [ ] Preserve at least three months of operating runway.
