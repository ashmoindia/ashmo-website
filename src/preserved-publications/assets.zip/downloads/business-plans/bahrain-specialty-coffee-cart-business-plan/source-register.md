# Source Register

Checked 2026-07-18. Confirm the latest rules with the relevant authority and add activity-specific sources before investment.

- [UAE Federal Tax Authority: VAT registration](https://tax.gov.ae/en/taxes/Vat/vat.topics/registration.for.vat.aspx)
- [UAE Ministry of Finance: corporate tax threshold](https://mof.gov.ae/en/news/ministry-of-finance-confirms-applicable-taxable-income-threshold-for-corporate-tax-abu-dhabi-uae/)

All startup, operating, revenue, and break-even figures in this pack are editable planning assumptions rather than sourced market quotations.
