# Launch Readiness Checklist

## Demand

- [ ] Interview 30 to 50 target households.
- [ ] Secure at least 10 paid pilot customers.
- [ ] Validate repeat intent and acceptable turnaround.

## Operations

- [ ] Test item tagging, handoff, quality checks, and lost-item handling.
- [ ] Compare at least two processing and delivery options.
- [ ] Define refund, re-clean, and complaint procedures.

## Compliance

- [ ] Confirm every licensed activity in writing.
- [ ] Confirm premises, layout, food-safety, signage, and transport approvals.
- [ ] Review VAT, corporate tax, employment, insurance, and record-keeping obligations.

## Finance

- [ ] Replace all estimates with supplier quotations.
- [ ] Complete downside, base, and upside cash-flow cases.
- [ ] Preserve at least three months of operating runway.
