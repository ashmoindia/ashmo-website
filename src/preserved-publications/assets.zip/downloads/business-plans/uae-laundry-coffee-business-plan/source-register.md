# Source Register

Checked 2026-07-12. Always confirm the latest rules with the relevant authority.

- [UAE Federal Tax Authority: VAT registration](https://tax.gov.ae/en/taxes/Vat/vat.topics/registration.for.vat.aspx)
- [UAE Ministry of Finance: corporate tax threshold](https://mof.gov.ae/en/news/ministry-of-finance-confirms-applicable-taxable-income-threshold-for-corporate-tax-abu-dhabi-uae/)
- [Dubai Municipality: food traders and establishments](https://www.dm.gov.ae/municipality-business/food-traders-establishments/)
- [Dubai Municipality: food establishment services](https://www.dm.gov.ae/municipality-business/food-safety-department-2/important-information-to-food-establishment/)

All startup, operating, revenue, and break-even figures in this pack are editable planning assumptions rather than sourced market quotations.
